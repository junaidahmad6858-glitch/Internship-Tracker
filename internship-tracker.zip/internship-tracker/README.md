# 💼 Internship Tracker

A responsive web application for managing internship and job applications in one place.

## Features
- Add, edit and delete applications
- Application status tracking
- Search by company or role
- Filter and sort applications
- Application and interview dates
- Notes and job links
- Dashboard statistics
- LocalStorage persistence
- Responsive UI
- Dark/light mode

## Technologies
HTML5 • CSS3 • JavaScript • LocalStorage • Git/GitHub

## Purpose
Built as a practical JavaScript project to strengthen DOM manipulation, CRUD operations, event handling, browser storage, responsive UI design and Git/GitHub skills.

## Run
Open `index.html` in a browser or use VS Code Live Server. No installation or backend is required.

## Author
**Junaid Ahmad Ansari** — BCA, Netaji Subhas University, Jamshedpur
